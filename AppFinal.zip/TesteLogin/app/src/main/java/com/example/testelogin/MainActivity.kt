package com.example.testelogin


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.testelogin.databinding.ActivityRegistroBinding
import com.google.firebase.auth.FirebaseAuth


class MainActivity : AppCompatActivity() {
    private lateinit var btnLogOut: Button
    private lateinit var binding: ActivityRegistroBinding
    private lateinit var firebaseAuth: FirebaseAuth

    var mAuth: FirebaseAuth? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnLogOut = findViewById(R.id.btnLogout)
        mAuth = FirebaseAuth.getInstance()
        btnLogOut.setOnClickListener {
            mAuth!!.signOut()
            startActivity(Intent(this@MainActivity, Login::class.java))
        }
    }

    override fun onStart() {
        super.onStart()
        val user = mAuth!!.currentUser
        if (user == null) {
            startActivity(Intent(this@MainActivity, Login::class.java))
        }
    }
}