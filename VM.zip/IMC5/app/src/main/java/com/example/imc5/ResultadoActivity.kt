package com.example.imc5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.AppCompatTextView

class ResultadoActivity : AppCompatActivity() {

    // para aqueles que já conhecem android ainda não estamos usando viewbinding
    // views
    private lateinit var tvVmResultado: AppCompatTextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        // referenciando a view
        tvVmResultado = findViewById(R.id.tvVmResultado)

        // checando se o parametro chegou direitinho
        if(intent.hasExtra("vm_resultado")){
            tvVmResultado.text = String.format("%.2f",intent.getDoubleExtra("vm_resultado",0.0))
        }else{
            // não chegou... o que fazer? Nda. Fechar.
            finish()
        }

    }
}