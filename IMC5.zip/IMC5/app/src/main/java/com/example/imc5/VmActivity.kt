package com.example.imc5

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import kotlin.math.pow

class VmActivity : AppCompatActivity(), View.OnClickListener {

    lateinit var btnCalcular: AppCompatButton
    lateinit var inputVi: AppCompatEditText
    lateinit var inputVf: AppCompatEditText
    lateinit var inputTi: AppCompatEditText
    lateinit var inputTf: AppCompatEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imc)
        btnCalcular = findViewById(R.id.btnCalcular)
        inputVi = findViewById(R.id.inputVi)
        inputVf = findViewById(R.id.inputVf)
        inputTi = findViewById(R.id.inputTi)
        inputTf = findViewById(R.id.inputTf)

        //etPeso.setOnClickListener(this)
        btnCalcular.setOnClickListener(this)
    }


    private fun hideSoftKeyboard(){
        val softKeyManager =
            getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        softKeyManager.hideSoftInputFromWindow(btnCalcular.windowToken, 0)
    }

    private fun calcularVm(Vi: Double, Vf: Double, Ti: Double, Tf: Double) : Double{
        if (Vi > 0.0 && Vf > 0.0 && Ti > 0.0 && Tf > 0.0) {
            return ((Vf - Vi) / (Tf - Ti))
        } else {
            throw IllegalArgumentException("Velocidades e Tempos devem ser maiores que zero.")
        }
    }


    override fun onClick(v: View?) {

        if (v!!.id == R.id.btnCalcular) {

            hideSoftKeyboard()

            val vi = inputVi.text.toString().toDouble()
            val vf = inputVf.text.toString().toDouble()
            val ti = inputVi.text.toString().toDouble()
            val tf = inputVf.text.toString().toDouble()

            // verificando se a altura e peso informados são maiores que zero.
            try {
                val vm = calcularVm(vi, vf, ti, tf)

                // criando a intent (para abrir a outra activity)
                val intentResultado = Intent(this,ResultadoActivity::class.java)

                // adicionando o parametro que desejamos
                intentResultado.putExtra("activity_resultado",vm)
                this.startActivity(intentResultado)

                finish()

            }catch (arg : IllegalArgumentException){
                Toast.makeText(this, arg.message, Toast.LENGTH_LONG).show()
            }
        }
    }
}